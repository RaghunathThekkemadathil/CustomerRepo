import { Component, EventEmitter, OnInit,Output } from '@angular/core';

@Component({
  selector: 'app-navtop',
  templateUrl: './navtop.component.html',
  styleUrls: ['./navtop.component.css']
})
export class NavtopComponent implements OnInit {
 topMenuItems=[];
 subMenuItems=[];
 @Output() onTopMenuItemClicked=new EventEmitter<any>();
  constructor() { }

  ngOnInit(): void {
    this.topMenuItems.push({menuId:1,caption:"Home",link:['/home']});
    this.topMenuItems.push({menuId:2,caption:"Management",link:['/management']});
    this.topMenuItems.push({menuId:3,caption:"AboutUs",link:['/aboutus']});

    this.subMenuItems.push({menuId:2,subMenuId:1,caption:"Customers",link:['/customers']});
    this.subMenuItems.push({menuId:2,subMenuId:2,caption:"Policies",link:['/policies']});
    
  }

  onTopMenuItemClick(menuid:any){
    var subMenuItemsFetched=this.subMenuItems.filter(f=>f.menuId==menuid);
  
    this.onTopMenuItemClicked.emit(subMenuItemsFetched);
  }
}
