import { NgModule, Optional, SkipSelf,APP_INITIALIZER} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { NavleftComponent } from './navleft/navleft.component';
import { NavtopComponent } from './navtop/navtop.component';
import { throwIfAlreadyLoaded } from './module-import-guard';
import {EnvironmentService} from './environment.service';

@NgModule({
    imports: [
      CommonModule, FormsModule, RouterModule
    ],
    exports: [
      CommonModule, FormsModule, RouterModule, [NavleftComponent],[NavtopComponent]
    ],
    declarations: [NavleftComponent,NavtopComponent],
    providers: [
      EnvironmentService,
      {provide : APP_INITIALIZER,useFactory:loadEnvironments,deps:[EnvironmentService],multi:true}
    ]
  })
  export class CoreModule {
    constructor( @Optional() @SkipSelf() parentModule: CoreModule) {
      throwIfAlreadyLoaded(parentModule, 'CoreModule');
    }
  }
  export function loadEnvironments(environmentService:EnvironmentService){
    return ()=> environmentService.getCurrentEnvironment();
   }