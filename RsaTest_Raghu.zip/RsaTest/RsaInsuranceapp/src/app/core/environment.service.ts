import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http'
import 'rxjs'
import {EnvironmentConfig} from './environmentconfig';
export function loadEnvironments(){
    
}
@Injectable()
export class EnvironmentService{
 environment:EnvironmentConfig;
 constructor(private httpClient:HttpClient){
     this.environment=new EnvironmentConfig();
 }
 getCurrentEnvironment():Promise<any>{
  const promise=this.httpClient.get('../assets/environmentconfig.json').toPromise().then(envSettings=>{
      this.environment=<EnvironmentConfig>envSettings;
      return envSettings;
  });
  return promise;
 }
}