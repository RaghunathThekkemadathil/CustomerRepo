import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-navleft',
  templateUrl: './navleft.component.html',
  styleUrls: ['./navleft.component.css']
})
export class NavleftComponent implements OnInit {
  @Input() subMenuItems=[];
  constructor() { }

  ngOnInit(): void {
   // console.log(this.subMenuItems);
  }

}
