import {Injectable} from '@angular/core';
export class EnvironmentConfig{
    environmentname:string;
    apiurl:string
}