import { NgModule } from '@angular/core';
import { routedComponents, CustomersRoutingModule} from './customer-routing.module';
import {CustomerService} from './shared/customer.service';
import {SharedModule} from '../shared/shared.module'
import { CustomerentryComponent } from './customerentry/customerentry.component';
@NgModule({
   imports: [CustomersRoutingModule,SharedModule],
    declarations: [routedComponents],
    providers: [CustomerService],
    entryComponents: [CustomerentryComponent]
  })
  export class CustomersModule { }