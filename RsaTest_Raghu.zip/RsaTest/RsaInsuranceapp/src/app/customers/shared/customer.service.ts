import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http'
import {Observable} from 'rxjs';
import {EnvironmentService} from '../../core'
@Injectable()
export class CustomerService{
  apiurl:string;
 constructor(private environmentService : EnvironmentService,private httpClient:HttpClient){
     this.apiurl=environmentService.environment.apiurl+'/customers';
 }
 getCustomers():Observable<any>{
   return this.httpClient.get<any>(this.apiurl);
 }
 getCustomerById(id) :Observable<any>{
  return this.httpClient.get<any>(this.apiurl + '/'+id,{withCredentials:false});
 }
 getCustomerByName(name){
   console.log(this.apiurl + '/getbyname/'+name);
  return this.httpClient.get<any>(this.apiurl + '/getbyname/'+name,{withCredentials:false});
 }
 addCustomer(customer){
  return this.httpClient.post(this.apiurl+'/add',customer,{withCredentials:false})
 }
 updateCustomer(customer){
   console.log(customer);
  return this.httpClient.put(this.apiurl+'/update',customer,{withCredentials:false})
 }
 deleteCustomer(id){
  return this.httpClient.delete(this.apiurl+'/delete/'+id)
 }
}