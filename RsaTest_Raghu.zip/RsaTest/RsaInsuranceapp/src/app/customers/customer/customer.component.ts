import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../shared/customer.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { FormBuilder, FormGroup } from '@angular/forms';
import { CustomerentryComponent } from '../customerentry/customerentry.component';
@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {
  customerForm: FormGroup;
  customerlist=[];

  constructor(private customerservice:CustomerService,private modalService: NgbModal) 
  { }

  ngOnInit( ): void {
     this.loadCustomers();
  
    }   
    showCustomerForm(model,eventdata:any){
     
      if(eventdata.smode=="Edit"){
        this.updateCustomer(eventdata.scustomer);
      }
      else{
        this.addCustomer(eventdata.scustomer);
      }
      
    }
    loadCustomers(){
      this.customerservice.getCustomers().subscribe((c)=>{
        this.customerlist=c;
      })
    }
    addCustomer(customer:any)
    {
      const modalRef = this.modalService.open(CustomerentryComponent, {
        centered: true,
        backdrop: 'static'
       });
       modalRef.componentInstance.customerData=customer;
         modalRef.result.then((result) => {
          if (result) {
            this.customerservice.addCustomer(result).subscribe(res=>{
             this.loadCustomers();
            })
          }
          });
    }
    updateCustomer(customer:any){
      this.customerservice.getCustomerById(customer.id).subscribe(res=>{
        const modalRef = this.modalService.open(CustomerentryComponent, {
          centered: true,
          backdrop: 'static'
         });
         modalRef.componentInstance.customerData=res;
         modalRef.result.then((result) => {
          if (result) {
            this.customerservice.updateCustomer(result).subscribe(res=>{
              this.loadCustomers();
            })
          }
          });
      })
    }
    deleteCustomer(eventdata:any){
      this.customerservice.deleteCustomer(eventdata.scustomer.id).subscribe(res=>{
        this.loadCustomers();
      })
    }
    getCustomerByName(eventdata:any){
      if(eventdata.scustomername.length>0){
      this.customerservice.getCustomerByName(eventdata.scustomername).subscribe(res=>{
        this.customerlist=res;
      })
    }
     else{this.loadCustomers();}
    }
  }
  


