import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-customerentry',
  templateUrl: './customerentry.component.html',
  styleUrls: ['./customerentry.component.css']
})
export class CustomerentryComponent implements OnInit {
  customerForm: FormGroup;
  @Input() customerData;
  constructor(public activeModal: NgbActiveModal,private fb: FormBuilder) { }

  ngOnInit(): void {
    this.customerForm=this.fb.group({
      id: [0],
      name: ['',[Validators.required]],
      email: ['',[Validators.required,Validators.email]]
     });

     this.customerForm.patchValue(this.customerData);
    }

    onSubmit() {
      var customer=this.customerForm.getRawValue();
      this.activeModal.close(customer);
    }
    onClose(){
      this.activeModal.close(null);
    }
  }


