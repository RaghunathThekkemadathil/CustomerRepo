import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {CustomerComponent} from './customer/customer.component'
import { CustomerlistComponent } from './customerlist/customerlist.component';
import {CustomerentryComponent} from './customerentry/customerentry.component';
const routes: Routes = [
    {
      path: '',
      component: CustomerComponent
      // no child paths to be set
    }]
@NgModule({
        imports: [RouterModule.forChild(routes)],
        exports: [RouterModule]
      })
export class CustomersRoutingModule { }
export const routedComponents = [CustomerComponent,CustomerlistComponent,CustomerentryComponent];