Setting up the angular application
-----------------------------------
Angular version : 10
Major Dependencies : Bootstrap , ngboostrap

1. Copy the folder RsaInsuranceapp
2. Open the project in vscode
3. Perform the npm install
4. Build and run the project

Notes: 

1.To view the customer screen click on the Management menu and then click on customers submenu
2.To set the api path go to environmentconfig in the assets folder and set the apiurl 

Setting up the web api
-----------------------------------
.Net core 3.1
Major Dependencies : Automapper, Moq,Pomelo.EntityFrameworkCore

1. Copy the folder RsaInsurance
2. Open the solution in visual studio


Setting up the database
---------------------------
Mariadb
DatabaseName : rsainsurancedb

1. Open the folder Database
2. Run the script






