using AutoMapper;
using Moq;
using RsaInsurance.Business;
using RsaInsurance.Business.Models;
using RsaInsurance.DataAccess.Context.Models;
using RsaInsurance.DataAccess.Repositories.Contracts;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;
using System.Linq;

namespace RsaInsurance.Test
{
    public class CustomerServiceTest
    {
        [Fact]
        public void Add_InsertNewCusomter_ReturnsSuccessAsTrue()
        {
            var mockrepository = new Mock<IRepository<Customer>>();
            var mockmapper = new Mock<IMapper>();
            mockmapper.Setup(x => x.Map<Customer>(It.IsAny<CustomerViewModel>()))
            .Returns((CustomerViewModel source) =>
            {
               return new Customer();
            });

            var customerservice = new CustomerService(mockrepository.Object, mockmapper.Object);
            var result = customerservice.AddCustomer(new CustomerViewModel{ Id = 5, Name = "John", Email = "John5" }) ;

            Assert.True(result.Result.Success);
        }
        [Fact]
        public void Update_ExistingCustomer_ReturnsSuccessAsTrue()
        {

            var updatecustomerwith = new CustomerViewModel { Id = 3, Name = "John Rigo", Email = "johnrigo@test.com" };
            var existingcustomer = new Customer { Id = 3, Name = "John3", Email = "john3@test.com" };
            var mockrepository = new Mock<IRepository<Customer>>();
            var mockmapper = new Mock<IMapper>();
            mockmapper.Setup(x => x.Map<Customer>(It.IsAny<CustomerViewModel>()))
            .Returns((CustomerViewModel source) =>
            {
                return new Customer();
            });
            mockrepository.Setup(x => x.Get(It.IsAny<int>())).Returns(Task.Run(()=> existingcustomer));
            var customerservice = new CustomerService(mockrepository.Object, mockmapper.Object);
            var result=customerservice.UpdateCustomer(updatecustomerwith);
            Assert.True(result.Result.Success);
        }
        [Fact]
        public void Update_NonExistingCustomer_ReturnsSuccessAsFalse()
        {

            var nonexistingcustomer = new CustomerViewModel { Id = 8, Name = "John Rigo", Email = "johnrigo@test.com" };
           
            var mockrepository = new Mock<IRepository<Customer>>();
            var mockmapper = new Mock<IMapper>();
            mockmapper.Setup(x => x.Map<Customer>(It.IsAny<CustomerViewModel>()))
            .Returns((CustomerViewModel source) =>
            {
                return new Customer();
            });
            mockrepository.Setup(x => x.Get(It.IsAny<int>())).Returns(Task.FromResult((Customer) null));
            var customerservice = new CustomerService(mockrepository.Object, mockmapper.Object);
            var result = customerservice.UpdateCustomer(nonexistingcustomer);
            Assert.False(result.Result.Success);
        }
        [Fact]
        public void Delete_ExistingCustomer_ReturnsSuccessAsTrue()
        {
            var customeridtodelete = 3;
            var existingcustomer = new Customer { Id = 3, Name = "John3", Email = "john3@test.com" };
            var mockrepository = new Mock<IRepository<Customer>>();
            var mockmapper = new Mock<IMapper>();
            mockmapper.Setup(x => x.Map<Customer>(It.IsAny<CustomerViewModel>()))
            .Returns((CustomerViewModel source) =>
            {
                return new Customer();
            });
            mockrepository.Setup(x => x.Get(It.IsAny<int>())).Returns(Task.Run(() => existingcustomer));
            var customerservice = new CustomerService(mockrepository.Object, mockmapper.Object);
            var result = customerservice.DeleteCustomer(customeridtodelete);
            Assert.True(result.Result.Success);
        }
        [Fact]
        public void Delete_NonExistingCustomer_ReturnsSuccessAsFalse()
        {
            var nonexistingcustomeridtodelete = 8;
            var mockrepository = new Mock<IRepository<Customer>>();
            var mockmapper = new Mock<IMapper>();
            mockmapper.Setup(x => x.Map<Customer>(It.IsAny<CustomerViewModel>()))
            .Returns((CustomerViewModel source) =>
            {
                return new Customer();
            });
            mockrepository.Setup(x => x.Get(It.IsAny<int>())).Returns(Task.FromResult((Customer)null));
            var customerservice = new CustomerService(mockrepository.Object, mockmapper.Object);
            var result = customerservice.DeleteCustomer(nonexistingcustomeridtodelete);
            Assert.False(result.Result.Success);
        }
        [Fact]
        public void Get_AllCustomers_ReturnsEntireList()
        {
            List<CustomerViewModel> customerviewList = new List<CustomerViewModel>();
            customerviewList.Add(new CustomerViewModel { Id = 1, Name = "John1", Email = "john1@test.com" });
            customerviewList.Add(new CustomerViewModel { Id = 2, Name = "John2", Email = "john2@test.com" });
            customerviewList.Add(new CustomerViewModel { Id = 3, Name = "John3", Email = "john2@test.com" });

            List<Customer> customerList = new List<Customer>();
            customerList.Add(new Customer { Id = 1, Name = "John1", Email = "john1@test.com" });
            customerList.Add(new Customer { Id = 2, Name = "John2", Email = "john2@test.com" });
            customerList.Add(new Customer { Id = 3, Name = "John3", Email = "john2@test.com" });

            var mockrepository = new Mock<IRepository<Customer>>();
            var mockmapper = new Mock<IMapper>();
            mockmapper.Setup(m => m.Map<List<Customer>, List<CustomerViewModel>>(It.IsAny<List<Customer>>()))
                      .Returns(customerviewList);
            
            mockrepository.Setup(x => x.GetAll()).Returns(Task.FromResult(customerList));
           
            var customerservice = new CustomerService(mockrepository.Object, mockmapper.Object);
            var result = customerservice.GetAllCustomers();
            Assert.Equal(3, result.Result.Count);
        }
        [Fact]
        public void Get_ExistingCustomer_ReturnsCustomer()
        {
            var customeridtofind = 3;
            var existingcustomer = new Customer { Id = 3, Name = "John3", Email = "john3@test.com" };
            var mockrepository = new Mock<IRepository<Customer>>();
            var mockmapper = new Mock<IMapper>();
            mockrepository.Setup(x => x.Get(It.IsAny<int>())).Returns(Task.Run(() => existingcustomer));
            mockmapper.Setup(m => m.Map<Customer, CustomerViewModel>(It.IsAny<Customer>()))
                      .Returns(new CustomerViewModel { Id = 3, Name = "John3", Email = "john3@test.com" });
            var customerservice = new CustomerService(mockrepository.Object, mockmapper.Object);
            var result = customerservice.GetCustomer(customeridtofind);
            Assert.Equal(customeridtofind, result.Result.Id);
        }
        [Fact]
        public void Get_NonExistingCustomer_ReturnsNull()
        {
            var customeridtofind = 8;
            var nonexistingcustomer = new Customer { Id = 8, Name = "John8", Email = "john8@test.com" };
            var mockrepository = new Mock<IRepository<Customer>>();
            var mockmapper = new Mock<IMapper>();
            mockrepository.Setup(x => x.Get(It.IsAny<int>())).Returns(Task.Run(() => (Customer)null));
            mockmapper.Setup(m => m.Map<Customer, CustomerViewModel>(It.IsAny<Customer>()))
                      .Returns((CustomerViewModel)null);
            var customerservice = new CustomerService(mockrepository.Object, mockmapper.Object);
            var result = customerservice.GetCustomer(customeridtofind);
            Assert.Null(result.Result);
        }

        [Fact]
        public void GetByName_ExistingCustomer_ReturnsCustomer()
        {
            var customernametofind = "Neil";
            var existingcustomerlist = new List<Customer>();
            var existingcustomerviewList = new List<CustomerViewModel>();
            existingcustomerlist.Add(new Customer { Id = 3, Name = "Neil", Email = "neil@test.com" });
            existingcustomerviewList.Add(new CustomerViewModel { Id = 3, Name = "Neil", Email = "neil@test.com" });
            var mockrepository = new Mock<IRepository<Customer>>();
            var mockmapper = new Mock<IMapper>();
            mockrepository.Setup(x => x.GetAll(It.IsAny<IFilterSpecification<Customer>>())).Returns(Task.Run(() => existingcustomerlist));
            mockmapper.Setup(m => m.Map<List<Customer>, List<CustomerViewModel>>(It.IsAny<List<Customer>>()))
                      .Returns(existingcustomerviewList);
            var customerservice = new CustomerService(mockrepository.Object, mockmapper.Object);
            var result = customerservice.GetAllCustomers(customernametofind);
            Assert.True(result.Result.Count > 0);
        }
        [Fact]
        public void GetByName_NonExistingCustomer_ReturnsNull()
        {
            var customernametofind = "Neil";
            var existingcustomerlist = new List<Customer>();
            var existingcustomerviewList = new List<CustomerViewModel>();
            existingcustomerlist.Add(new Customer { Id = 3, Name = "John", Email = "john@test.com" });
            existingcustomerviewList.Add(new CustomerViewModel { Id = 3, Name = "John", Email = "john@test.com" });
            var mockrepository = new Mock<IRepository<Customer>>();
            var mockmapper = new Mock<IMapper>();
            mockrepository.Setup(x => x.GetAll(It.IsAny<IFilterSpecification<Customer>>())).Returns(Task.Run(() => ((List<Customer>) null)));
            mockmapper.Setup(m => m.Map<List<Customer>, List<CustomerViewModel>>(It.IsAny<List<Customer>>()))
                      .Returns((List<CustomerViewModel>)null);
            var customerservice = new CustomerService(mockrepository.Object, mockmapper.Object);
            var result = customerservice.GetAllCustomers(customernametofind);
            Assert.Null(result.Result);
        }
    }
}
