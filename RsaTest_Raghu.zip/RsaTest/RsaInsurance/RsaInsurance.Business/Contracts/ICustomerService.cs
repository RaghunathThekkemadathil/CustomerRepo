﻿using RsaInsurance.Business.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace RsaInsurance.Business.Contracts
{
   public interface ICustomerService
    {
        Task<List<CustomerViewModel>> GetAllCustomers();
        Task<CustomerViewModel> GetCustomer(int id);
        Task<List<CustomerViewModel>> GetAllCustomers(string name);
        Task<ActionResponse<CustomerViewModel>> AddCustomer(CustomerViewModel customerViewModel);
        Task<ActionResponse<CustomerViewModel>> UpdateCustomer(CustomerViewModel customerViewModel);
        Task<ActionResponse<CustomerViewModel>> DeleteCustomer(int id);
    }
}
