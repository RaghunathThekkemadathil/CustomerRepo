﻿using RsaInsurance.DataAccess.Context.Models;
using RsaInsurance.DataAccess.Repositories.Contracts;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;

namespace RsaInsurance.Business.Filter
{
    public class FilterByName : IFilterSpecification<Customer>
    {
        public string _name;
        public FilterByName(string name)
        {
            _name = name;
        }
        public Expression<Func<Customer, bool>> Criteria => x => x.Name.ToLower().Contains(_name.ToLower());
    }
}
