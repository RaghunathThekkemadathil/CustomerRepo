﻿using AutoMapper;
using Microsoft.Extensions.DependencyInjection;
using RsaInsurance.Business.Models;
using RsaInsurance.DataAccess.Context.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace RsaInsurance.Business.Mapping
{
    public static class AutoMapperConfig
    {
        public static void AddAutoMapper(this IServiceCollection services)
        {
            var mappingconfig = new MapperConfiguration(mc => { mc.RegisterMappings(); mc.AllowNullCollections = true; mc.AllowNullDestinationValues = true; });
            services.AddTransient(t => mappingconfig.CreateMapper());
        }
        public static void RegisterMappings(this IMapperConfigurationExpression configurationExpression)
        {
            configurationExpression.CreateMap<Customer,CustomerViewModel>().ReverseMap();
        }
    }
}
