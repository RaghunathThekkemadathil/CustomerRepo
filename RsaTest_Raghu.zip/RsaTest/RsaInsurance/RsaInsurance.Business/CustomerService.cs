﻿using AutoMapper;
using RsaInsurance.Business.Contracts;
using RsaInsurance.Business.Filter;
using RsaInsurance.Business.Models;
using RsaInsurance.DataAccess.Context.Models;
using RsaInsurance.DataAccess.Repositories.Contracts;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace RsaInsurance.Business
{
    public class CustomerService : ICustomerService
    {
        IRepository<Customer> _customerrepository;
        IMapper _mapper;
        public CustomerService(IRepository<Customer> customerrepository,IMapper mapper)
        {
            _customerrepository = customerrepository;
            _mapper = mapper;
        }
        public async Task<List<CustomerViewModel>> GetAllCustomers()
        {
            return _mapper.Map<List<Customer>,List<CustomerViewModel>>(await _customerrepository.GetAll());
        }
        public async Task<List<CustomerViewModel>> GetAllCustomers(string byname)
        {
            IFilterSpecification<Customer> filterSpecification = new FilterByName(byname);
            return _mapper.Map<List<Customer>, List<CustomerViewModel>>(await _customerrepository.GetAll(filterSpecification));
        }
        public async Task<CustomerViewModel> GetCustomer(int id)
        {
            return _mapper.Map<Customer, CustomerViewModel>(await _customerrepository.Get(id));
        }
        public async Task<ActionResponse<CustomerViewModel>> AddCustomer(CustomerViewModel customerViewModel)
        {
            var Customer = _mapper.Map<CustomerViewModel, Customer>(customerViewModel);

            Customer = await _customerrepository.Add(Customer);

            await _customerrepository.Commit();

            return new ActionResponse<CustomerViewModel>(customerViewModel, "Added", true);
        }

        public async Task<ActionResponse<CustomerViewModel>> DeleteCustomer(int id)
        {
            var retreivedCustomer = await _customerrepository.Get(id);
            if (retreivedCustomer == null)
            {
                return new ActionResponse<CustomerViewModel>(new CustomerViewModel(), "Not Found", false);
            }
           
            _customerrepository.Delete(retreivedCustomer);
            await _customerrepository.Commit();
            return new ActionResponse<CustomerViewModel>(_mapper.Map<Customer,CustomerViewModel>(retreivedCustomer), "Deleted", true);
        }
        public async Task<ActionResponse<CustomerViewModel>> UpdateCustomer(CustomerViewModel customerViewModel)
        {
            var retreivedCustomer = await _customerrepository.Get(customerViewModel.Id);
            if (retreivedCustomer == null)
            {
                return new ActionResponse<CustomerViewModel>(customerViewModel, "Not Found", false);
            }
            var Customer = _mapper.Map<CustomerViewModel, Customer>(customerViewModel);
            _customerrepository.Update(retreivedCustomer,Customer);
            await _customerrepository.Commit();
            return new ActionResponse<CustomerViewModel>(customerViewModel, "Updated", true);
        }

       
    }
}
