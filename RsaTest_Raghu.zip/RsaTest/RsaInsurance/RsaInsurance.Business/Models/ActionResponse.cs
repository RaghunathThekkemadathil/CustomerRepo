﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RsaInsurance.Business.Models
{
    public  class ActionResponse<T>
    {
        public bool Success { get; private set; }
        public string Message { get; private set; }
        public T Resource { get; private set; }

        public ActionResponse(T resource,string message,bool actionstatus)
        {
            Success = actionstatus;
            Message = message;
            Resource = resource;
        }
       
    }
}
