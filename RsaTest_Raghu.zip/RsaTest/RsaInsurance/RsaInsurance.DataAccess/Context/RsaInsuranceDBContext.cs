﻿using Microsoft.EntityFrameworkCore;
using RsaInsurance.DataAccess.Context.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace RsaInsurance.DataAccess.Context
{
    public partial class RsaInsuranceDbContext : Microsoft.EntityFrameworkCore.DbContext
    {
        public RsaInsuranceDbContext(DbContextOptions<RsaInsuranceDbContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Customer> Customers { get; set; }
    }
}
