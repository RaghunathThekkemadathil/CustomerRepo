﻿using Microsoft.EntityFrameworkCore;
using RsaInsurance.DataAccess.Context;
using RsaInsurance.DataAccess.Repositories.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RsaInsurance.DataAccess
{
    public class Repository<T> : IRepository<T> where T:class
    {
        private readonly RsaInsuranceDbContext _rsaInsuranceDBContext;
        private readonly DbSet<T> _dbSet;

        public Repository(RsaInsuranceDbContext rsaInsuranceDbContext) {
            _rsaInsuranceDBContext = rsaInsuranceDbContext;
            _dbSet = _rsaInsuranceDBContext.Set<T>();
        }

        public async Task<T> Add(T entity)
        {
             await _dbSet.AddAsync(entity);
            return entity;
        }

        public async Task<int> Commit()
        {
            return await _rsaInsuranceDBContext.SaveChangesAsync();
        }

        public async Task<T> Get(int id)
        {
            return await _dbSet.FindAsync(id);
        }

        public async Task<List<T>> GetAll()
        {
            return await _dbSet.AsNoTracking().ToListAsync();
        }
        public async Task<List<T>> GetAll(IFilterSpecification<T> filterSpecification)
        {

            return await _dbSet.AsQueryable().Where(filterSpecification.Criteria).ToListAsync();
        }

        public void Update(T oldentity,T newentity)
        {
            _rsaInsuranceDBContext.Entry(oldentity).CurrentValues.SetValues(newentity);
        }
        public void Delete(T entity)
        {
            _dbSet.Remove(entity);
        }

        
    }
}
