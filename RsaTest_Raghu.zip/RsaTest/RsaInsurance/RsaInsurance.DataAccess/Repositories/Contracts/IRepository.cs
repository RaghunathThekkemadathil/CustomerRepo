﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace RsaInsurance.DataAccess.Repositories.Contracts
{
    public interface IRepository <T>
    {
        Task<List<T>> GetAll();
        Task<List<T>> GetAll(IFilterSpecification<T> filterSpecification);
        Task<T> Get(int id);
        Task<T> Add(T entity);
        void Update(T oldentity,T newentity);
        void Delete(T entity);
        Task<int> Commit();
    }
}
