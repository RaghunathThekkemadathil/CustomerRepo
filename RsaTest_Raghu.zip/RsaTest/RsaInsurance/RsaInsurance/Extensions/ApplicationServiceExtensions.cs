﻿using Microsoft.AspNetCore.Builder;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Pomelo.EntityFrameworkCore.MySql.Infrastructure;
using RsaInsurance.Business;
using RsaInsurance.Business.Contracts;
using RsaInsurance.Business.Mapping;
using RsaInsurance.Common.ActionFilters;
using RsaInsurance.Common.Exceptions;
using RsaInsurance.DataAccess;
using RsaInsurance.DataAccess.Context;
using RsaInsurance.DataAccess.Repositories.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RsaInsurance.Extensions
{
    public static class ApplicationServiceExtensions
    {
        public static void RegisterDependencies(this IServiceCollection services)
        {
            services.AddAutoMapper();
            services.AddTransient(typeof(IRepository<>), typeof(Repository<>));
            services.AddTransient<ICustomerService, CustomerService>();
        }
        public static void ConfigureCorsPolicy(this IServiceCollection services)
        {
            services.AddCors(options =>
            {
                options.AddPolicy("rsapolicy", builder => builder.AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader());
            });
        }
        public static void ConfigureDatabaseConnection(this IServiceCollection services,IConfiguration Configuration)
        {
            services.AddDbContextPool<RsaInsuranceDbContext>(options => options
           .UseMySql(
           Configuration.GetConnectionString("DbConnectionString"),
           mySqlOptions => mySqlOptions.ServerVersion(new Version(10, 5, 8), ServerType.MariaDb)
           ));
        }
        public static void ConfigureActionFilters(this IServiceCollection services)
        {
            services.AddControllers(c => { c.Filters.Add(new ModalStateValidationFilter()); });
        }
        public static void ConfigureExceptionHandler(this IApplicationBuilder applicationBuilder)
        {
            applicationBuilder.UseMiddleware<ExceptionHandler>();
        }
    }
}
