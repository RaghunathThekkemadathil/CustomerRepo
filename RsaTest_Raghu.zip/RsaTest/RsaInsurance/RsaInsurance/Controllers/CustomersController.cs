﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using RsaInsurance.Business;
using RsaInsurance.Business.Contracts;
using RsaInsurance.Business.Models;
using Microsoft.AspNetCore.Cors;

namespace RsaInsurance.Controllers
{
    [EnableCors("rsapolicy")]
    [ApiController]
    [Route("[controller]")]
    public class CustomersController : ControllerBase
    {
        ICustomerService _customerService;
        public CustomersController(ICustomerService customerService)
        {
            _customerService = customerService;
        }

        [HttpGet]
        public async Task<List<CustomerViewModel>> Get()
        {
            return await _customerService.GetAllCustomers();
        }
        [HttpGet("{id}")]
        public async Task<CustomerViewModel> Get(int id)
        {
            return await _customerService.GetCustomer(id);
        }
        [HttpGet("getbyname/{name}")]
        public async Task<List<CustomerViewModel>> GetByName(string name)
        {
            return await _customerService.GetAllCustomers(name);
        }
        [HttpPost("add")]
        public async Task<IActionResult> Add([FromBody] CustomerViewModel customerViewModel)
        {
            return Ok(await _customerService.AddCustomer(customerViewModel));
        }
        [HttpPut("update")]
        public async Task<IActionResult> Update([FromBody] CustomerViewModel customerViewModel)
        {
            return Ok(await _customerService.UpdateCustomer(customerViewModel));
        }
        [HttpDelete("delete/{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            return Ok(await _customerService.DeleteCustomer(id));
        }
       
    }
}
