﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace RsaInsurance.Common.Exceptions
{
    public class Error
    {
        public int StatusCode { get; set; }
        public string Message { get; set; }

    }
    public class ExceptionHandler
    {
        private readonly RequestDelegate _next;
        public ExceptionHandler(RequestDelegate next)
        {
            _next = next;
        }
        public async Task InvokeAsync(HttpContext httpContext)
        {
            try
            {
                await _next(httpContext);

            }catch(Exception ex)
            {
               await HandleException(httpContext, ex);
            }
        }
        public Task HandleException(HttpContext httpContext,Exception exception)
        {
            httpContext.Response.ContentType = "application/json";
            httpContext.Response.StatusCode = (int)HttpStatusCode.InternalServerError;
            return httpContext.Response.WriteAsync(new Error { StatusCode= httpContext.Response.StatusCode,Message=exception.Message }.ToString());
        }
    }
}
